
  # Activity Feed Design

  This is a code bundle for Activity Feed Design. The original project is available at https://www.figma.com/design/pU7EE0jkxNq8J2QnEl3vRE/Activity-Feed-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  